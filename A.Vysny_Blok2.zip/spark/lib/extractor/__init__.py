# Extractor utilities for Spark jobs
