# VINF Pipeline

Data processing pipeline for analyzing GitHub repositories with Wikipedia enrichment.
