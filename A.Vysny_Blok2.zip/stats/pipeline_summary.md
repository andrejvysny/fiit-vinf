# VINF Pipeline Statistics Report

**Generated:** 2025-12-11T20:04:23.151071
**Overall Status:** completed
**Total Duration:** 0.00 seconds

---

## 2. HTML Extraction

- **Status:** completed
- **Duration:** 0.00 seconds
- **Files Processed:** 28,353
- **Text Files Written:** 28,353
- **Total Entities:** 10,585,183

---

## Summary

| Metric | Value |
|--------|-------|
| Total Duration | 0.00s |
| Wiki Pages Processed | 0 |
| HTML Files Processed | 28,353 |
| Total Entities Extracted | 10,585,183 |
| Total Joins | 0 |
