"""Unit tests for the GitHub crawler and indexer project."""
